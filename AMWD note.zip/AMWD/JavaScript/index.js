console.log('AMWD');

document.write('Chamikara Ruchiranga');
document.write('<h3>ACPT</h3>');
document.write('<button>AMWD</button><br><br>');
document.write('<input type="text"/><button>Submit</button>');

// Numbers 
const num = 10.5;

// String 
const stri = "ACPT 50";

// Boolean 
const bool = false;

// Object
const obj = {name: 'chamikara', address: 'panadura'};

// Array 
const array = [{}, false, 'Chamikara', 100, []];



// let 
let a = 10;
console.log(a);
a = 50;
console.log(a)
{let ab = 100;}
// console.log(ab);

// let a = 20;

// var 
var v = 10;
var v = true;
console.log(v);
{var vv = 888}
vv = 999;
console.log(vv);

// const 
const co = 10;
// const co = 20;
console.log(co);
// co = 30;
{const coo = 'acpt'}
// console.log(coo);


// Arithmetic Operators 
// Addition (+)
const s = 20;
const d = 10;
const addition = s + d;
console.log(addition);

// Subtraction (-)
const subtraction = s - d;
console.log(subtraction);

// Multiplication (*)
const mult = s * d;
console.log(mult);

// Division (/)
const division = s/d;
console.log(division);

// Moduls (%)
const mo = s%d;
console.log(mo);

// Increment (++)
let h = 10;
h++
h++
console.log(h);

// Decrement (--)
let i = 20;
i--
i--
console.log(i);

// Comparison Operators 
const l = '13';
const m = 13;
// Equal (==)
console.log(l == m);

